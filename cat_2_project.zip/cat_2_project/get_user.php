<!-- Get User Page -->

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
  <br>
  <br>
<div style="text-align: center;">
  <h3>Get User</h3>
  <br>
    <form action="" method="POST">
    <input type="text" name="email" required placeholder="My Email">
    <br>
    <input type="password" name="password" required placeholder="Password">
    <br>
    <input type="submit" name="get" required value="Login">
  </form>
</div>
</body>
</html>

<?php

$conn = mysqli_connect("localhost","root","","work_database");

if (isset($_POST['get'])){
 $email = $_POST['email'];
 $password = $_POST['password'];
   
    $query = "SELECT * FROM `work_users` WHERE `email` = '$email'";

        $result = mysqli_query($conn,$query);

        if(mysqli_num_rows($result) > 0){
          $row = mysqli_fetch_assoc($result);
          $pass = $row['password'];
   if(md5($password) == $pass){
          header("Location: select_user.php");
}
}
}

?>