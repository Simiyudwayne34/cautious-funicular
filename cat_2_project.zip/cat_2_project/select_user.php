<!-- Main Page -->

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
  <br>
  <br>
  <div>
    <ol>
      <li><a href="get_user.php">Log Out</a></li>
    </ol>
  </div>
  <div>
  <h1>Selection of Users</h1>
  <br>
     <table>
                <tr style="text-align: center;
                  padding: 12px;">
                <th style="text-align: center;
                  padding: 12px;">ID</th>
                <th style="text-align: center;
                  padding: 12px;">Name</th>
               <th style="text-align: center;
                  padding: 12px;">Email Address </th>
                   <th style="text-align: center;
                  padding: 12px;">Picture</th>
                   <th style="text-align: center;
                  padding: 12px;">Password</th>
                </tr>

                <?php
                $conn = mysqli_connect("localhost", "root", "", "work_database");
                if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
                }

$query = "SELECT * FROM `work_users`";
$result = mysqli_query($conn, $query);
if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["id"]); ?></td>
<td><?php echo($row["name"]); ?></td>
<td><?php echo($row["email"]); ?></td>
<td><img style="width: 200px;" src='userpics/<?php echo($row["image"]); ?>'></td>
<td><?php echo(md5($row["password"])); ?></td>
</tr>
<?php
}
} else { echo "No records present."; }
$conn->close();
?>
                </table>
</div>
<br>
<br>
<div style="text-align: center;">
  <h3>Update My Details</h3>
  <br>
    <form action="" method="POST">
    <input type="text" name="id" required placeholder="My ID">
    <br>
    <input type="text" name="name" required placeholder="My Name">
    <br>
    <input type="text" name="email" required placeholder="Email Address">
    <br>
    <input type="password" name="password" required placeholder="Password">
    <br>
    <input type="password" name="cpassword" required placeholder="Confirm Password">
    <br>
    <input type="submit" name="push" required value="Update">
  </form>
  <br>
</div>
</body>
</html>

<?php

$conn = mysqli_connect("localhost","root","","work_database");

if (isset($_POST['push'])) {

 $id = $_POST['id'];
 $name = $_POST['name'];
 $email = $_POST['email'];
 $no = $_POST['no'];
 $age = $_POST['age'];
 $hobby = $_POST['hobby'];
 $password = $_POST['password'];
 $password1 = $_POST['cpassword'];
   if($password == $password1){
   $query = "UPDATE `work_users` SET `name`='$name',`email`='$email',`password`=md5('$password') WHERE `id`='$id'";
     mysqli_query($conn, $query);
     header("Location: select_user.php");
   }else{
    echo "<script>alert('Passwords Do Not Match!');</script>";
   }
}

?>