<!-- Add User Page -->

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
  <br>
  <br>
<div style="text-align: center;">
  <h3>Add User</h3>
  <br>
  <form action="" method="POST" enctype="multipart/form-data">
    <input type="text" name="id" required placeholder="Your ID">
    <br>
    <input type="text" name="name" required placeholder="Your Name">
    <br>
    <input type="text" name="email" required placeholder="Your Email">
    <br>
    <input type="file" name="image" required>
    <br>
    <input type="password" name="password" required placeholder="Password">
    <br>
    <input type="password" name="cpassword" required placeholder="Password">
    <br>
    <input type="submit" name="post" required value="Sign Up">
  </form>
  <br>
</div>
</body>
</html>

<?php

$conn = mysqli_connect("localhost","root","","work_database");

if (isset($_POST['post'])) {

 $id = $_POST['id'];
 $name = $_POST['name'];
 $email = $_POST['email'];
 $no = $_POST['no'];
 $age = $_POST['age'];
 $hobby = $_POST['hobby'];
 $password = $_POST['password'];
  $password1 = $_POST['cpassword'];
   if($password == $password1){

      if ($_FILES["image"]["error"] === 4) {
   echo "<script> alert('Image does not exist!');</script>";
  }else{
  $uploads_dir = 'userpics';
  $fileName = $_FILES["image"]["name"];
  $fileSize = $_FILES["image"]["size"];
  $tmpName = $_FILES["image"]["tmp_name"];

  $validImageExtension = ['jpg', 'jpeg', 'png'];
  $imageExtension = explode('.', $fileName);
  $imageExtension = strtolower(end($imageExtension));

  if (!in_array($imageExtension, $validImageExtension)) {
    echo "<script> alert('Invalid Image Format!');</script>";
  }else if($fileSize > 10000000){
    echo "<script> alert('Image is too large!');</script>";
  }else{

    $newImgName = uniqid();
    $newImgName .= '.' . $imageExtension;

    move_uploaded_file($tmpName, "$uploads_dir/$newImgName");

    $query = "INSERT INTO `work_users`(`id`, `name`, `email`, `image`,`password`) VALUES ('$id','$name','$email','$newImgName',md5('$password'))";

     mysqli_query($conn, $query);
     header("Location: get_user.php");
}
}
}else{
    echo "<script>alert('Passwords Do Not Match!');</script>";
   }
 }

?>